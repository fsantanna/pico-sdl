var searchData=
[
  ['building_20pico_20sdl_0',['Building pico-sdl',['../index.html#autotoc_md3',1,'']]]
];
