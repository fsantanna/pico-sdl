var searchData=
[
  ['init_0',['Init',['../group__Init.html',1,'']]],
  ['input_1',['Input',['../group__Input.html',1,'']]],
  ['is_20pico_20sdl_2',['What is pico-sdl?',['../index.html#autotoc_md1',1,'']]]
];
